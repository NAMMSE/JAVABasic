package quiz; // ��Ű�� �ȿ� ���� Ŭ������ �ִٴ� ǥ��

public class A00_rabbit {
	public static void main(String[] args) {
	/*System.out.println("====================");
	System.out.println("        /)/)        ");
	System.out.println("       (  ..)       ");
	System.out.println("       (  >��        ");
	System.out.println("  HAVE a Good Time. ");
	System.out.println("====================");
	*/
		
		System.out.println("===================="
						+ "\n        /)/)"
						+ "\n       (  ..)"
						+ "\n       (  >��"
						+ "\n  HAVE a Good Time."
						+ "\n====================");
		
	}
}
