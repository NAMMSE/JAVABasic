package quiz;

public class A04_profile {

	public static void main(String[] args) {
		
		String name = "ȫ�浿";
		int age = 20;
		String Tel = "010-1234-1234";
		double height = 178.5;
		double weight = 75;
		String bt = "o";
		
		System.out.println("==========��� ���==========\n\n"
						+ "�̸� :" + name   + "\n"
						+ "���� :" + age    + "\n"
						+ "Tel :" + Tel    + "\n"
						+ "Ű :"   + height + "\n"
						+ "������ :" + weight + "\n"
						+ "������ :" + bt);
	}
}
