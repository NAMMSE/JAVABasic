package gui.quiz;

import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

import gui.quiz.hangman.HangMainFrame;

public class S07_HangMan_t extends JFrame{
	// ��� ����� �ڵ�
	
	public S07_HangMan_t() {
	
	}
	
	public static void main(String[] args) {
		new HangMainFrame();
	}
}
