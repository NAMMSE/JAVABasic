package myobj.blackjack;

abstract public class Deck {

	abstract public void shuffle();
	abstract public Card draw ();
}
