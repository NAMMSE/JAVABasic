package myobj.student;

public interface GradeCard {

	void printGradeCard();
}
