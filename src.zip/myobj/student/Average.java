package myobj.student;

public interface Average {

	int sum();
	double avg();
	
}
