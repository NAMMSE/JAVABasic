package myobj.parking;

public class CarType { // 0517 ȭ

	private int value; // 0 1 2 3 
	private String name; // �Ϲ� ����� ���Ƶ��� ����
	
	
	public CarType(int value, String name) { 
		this.value = value;
		this.name = name;
	
	}
	public int getValue() {
		return value;
	}
	
	public String getName() {
		return name;
	}
	
	
}

